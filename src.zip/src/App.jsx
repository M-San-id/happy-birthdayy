import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./Home";
import Message from "./Message";
import Quotes from "./Quotes";
import MiniGame from "./MiniGame";
import Navbar from "./component/navbar/Navbar";

function App() {
  return (
    <Router>
      <div className="container">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/message" element={<Message />} />
          <Route path="/quotes" element={<Quotes />} />
          <Route path="/mini-game" element={<MiniGame />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

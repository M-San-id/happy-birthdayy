import React, { useState, useEffect } from "react";
import "./Quotes.css";

const fullText = `Lorem ipsum dolor, sit amet consectetur adipisicing elit.
Blanditiis exercitationem quaerat perspiciatis accusantium
sapiente culpa reiciendis tenetur quidem praesentium impedit
rerum, nemo, fugiat officiis, neque id non aut dolor error.
Accusantium suscipit esse, nisi quaerat non officiis adipisci
dolores? Quos magnam, debitis sed cumque sequi, culpa aut,
consequuntur eos suscipit atque velit dolorum deserunt vitae a
deleniti modi repellat reiciendis. Fugiat mollitia obcaecati,
culpa dolores tempora error. Ipsa, molestiae. Tempore porro
perferendis omnis minus. Esse totam blanditiis rerum ullam fuga
alias quis earum cupiditate numquam illum, nulla provident eum
vel.`;

function Quotes() {
  const [displayedText, setDisplayedText] = useState("");

  useEffect(() => {
    let i = 0;
    const interval = setInterval(() => {
      setDisplayedText(fullText.slice(0, i + 1));
      i++;
      if (i === fullText.length) clearInterval(interval);
    }, 15); // kecepatan mengetik (ms)
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <div className="quote-container">
        <div className="board">
          <h1>Ini Rill ini hati saya hehe</h1>
          <div className="quote">
            <p>{displayedText}</p>
          </div>
        </div>
      </div>
    </>
  );
}

export default Quotes;
